"""chess-pras: a compact chess engine for tiny-chess-01.

Original implementation: 0..63 board of signed integers, legal move generator,
negamax alpha-beta with quiescence, transposition table, killers, and a
material + piece-square evaluation. Search is bounded by nodes and depth,
never by a clock, so replayed trials are identical.
"""
import json
import os
import sys
import urllib.error
import urllib.request

V = [0, 100, 320, 330, 500, 900, 20000]
PROMO = (5, 2, 3, 4)  # queen, rook, bishop, knight
INF = 100000
MATE = 90000
LIMIT = 45000
MAXD = 7

# Piece-square tables, rank 1 to rank 8, from white's point of view.
PST = [
 [0]*64,
 [0,0,0,0,0,0,0,0, 8,12,12,-18,-18,12,12,8, 6,-4,-8,2,2,-8,-4,6,
  2,2,4,16,16,4,2,2, 6,8,12,22,22,12,8,6, 14,16,20,28,28,20,16,14,
  48,48,48,48,48,48,48,48, 0,0,0,0,0,0,0,0],
 [-46,-36,-28,-28,-28,-28,-36,-46, -36,-16,4,8,8,4,-16,-36,
  -26,6,14,18,18,14,6,-26, -26,2,18,24,24,18,2,-26,
  -26,6,18,24,24,18,6,-26, -26,2,14,18,18,14,2,-26,
  -36,-16,2,6,6,2,-16,-36, -46,-36,-28,-28,-28,-28,-36,-46],
 [-20,-12,-10,-10,-10,-10,-12,-20, -10,8,4,4,4,4,8,-10,
  -10,12,12,12,12,12,12,-10, -10,4,14,14,14,14,4,-10,
  -10,6,10,14,14,10,6,-10, -10,2,8,12,12,8,2,-10,
  -10,4,4,4,4,4,4,-10, -20,-12,-10,-10,-10,-10,-12,-20],
 [0,0,4,8,8,4,0,0, -6,0,2,4,4,2,0,-6, -6,0,2,4,4,2,0,-6,
  -6,0,2,4,4,2,0,-6, -6,0,2,4,4,2,0,-6, -6,0,2,4,4,2,0,-6,
  10,14,14,14,14,14,14,10, 0,0,2,6,6,2,0,0],
 [-20,-12,-10,-6,-6,-10,-12,-20, -12,0,6,2,2,4,0,-12,
  -10,6,8,8,8,8,6,-10, -4,2,8,10,10,8,2,-4,
  -4,2,8,10,10,8,2,-4, -10,4,6,8,8,6,4,-10,
  -10,2,4,4,4,4,2,-10, -20,-12,-10,-6,-6,-10,-12,-20],
 [18,28,10,0,0,10,28,18, 18,18,0,-4,-4,0,18,18,
  -12,-20,-22,-24,-24,-22,-20,-12, -22,-30,-34,-40,-40,-34,-30,-22,
  -28,-38,-42,-48,-48,-42,-38,-28, -30,-40,-44,-50,-50,-44,-40,-30,
  -32,-42,-46,-52,-52,-46,-42,-32, -32,-42,-46,-52,-52,-46,-42,-32],
]

# Move tables for knights, kings and sliding pieces.
def step_table(deltas):
    out = []
    for sq in range(64):
        r, c = divmod(sq, 8)
        out.append([(r + dr) * 8 + c + dc for dc, dr in deltas
                    if 0 <= r + dr < 8 and 0 <= c + dc < 8])
    return out

def ray_table(deltas):
    out = []
    for sq in range(64):
        r, c = divmod(sq, 8)
        rays = []
        for dc, dr in deltas:
            ray = []
            rr, cc = r + dr, c + dc
            while 0 <= rr < 8 and 0 <= cc < 8:
                ray.append(rr * 8 + cc)
                rr += dr
                cc += dc
            if ray:
                rays.append(ray)
        out.append(rays)
    return out

KN = step_table([(1,2),(2,1),(2,-1),(1,-2),(-1,-2),(-2,-1),(-2,1),(-1,2)])
KG = step_table([(1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1)])
BR = ray_table([(1,1),(1,-1),(-1,1),(-1,-1)])
RR = ray_table([(1,0),(-1,0),(0,1),(0,-1)])

def attacked(b, sq, by):
    r, c = divmod(sq, 8)
    for dc in (-1, 1):
        cc = c - by * dc
        rr = r - by
        if 0 <= cc < 8 and 0 <= rr < 8 and b[rr * 8 + cc] == by:
            return True
    for t in KN[sq]:
        if b[t] == by * 2:
            return True
    for t in KG[sq]:
        if b[t] == by * 6:
            return True
    for rays in BR[sq]:
        for t in rays:
            p = b[t]
            if p:
                if p * by in (3, 5):
                    return True
                break
    for rays in RR[sq]:
        for t in rays:
            p = b[t]
            if p:
                if p * by in (4, 5):
                    return True
                break
    return False

def gen(st, caps=False):
    b, side, cast, ep, hm, key, wk, bk = st
    for f, p in enumerate(b):
        if p * side <= 0:
            continue
        k = p * side
        if k == 1:
            t = f + 8 * side
            if 0 <= t < 64 and b[t] == 0:
                if not caps or t < 8 or t > 55:
                    if t > 55 or t < 8:
                        for pr in range(4):
                            yield (f, t, pr)
                    else:
                        yield (f, t, -1)
                        if f // 8 == (1 if side == 1 else 6) and b[t + 8 * side] == 0:
                            yield (f, t + 8 * side, -1)
            for t in (f + 7 * side, f + 9 * side):
                if not 0 <= t < 64 or abs((t & 7) - (f & 7)) != 1:
                    continue
                if b[t] * side < 0 or t == ep:
                    if t > 55 or t < 8:
                        for pr in range(4):
                            yield (f, t, pr)
                    else:
                        yield (f, t, -1)
        elif k in (2, 6):
            for t in KN[f] if k == 2 else KG[f]:
                if b[t] * side <= 0 and not caps:
                    yield (f, t, -1)
        else:
            for rays in (BR[f] if k in (3, 5) else []) + (RR[f] if k in (4, 5) else []):
                for t in rays:
                    q = b[t]
                    if q == 0:
                        if not caps:
                            yield (f, t, -1)
                    else:
                        if q * side < 0:
                            yield (f, t, -1)
                        break
    if caps:
        return
    kingside = bool(cast & (1 if side == 1 else 4))
    queenside = bool(cast & (2 if side == 1 else 8))
    ksq = wk if side == 1 else bk
    if 0 <= ksq < 64 and not attacked(b, ksq, -side):
        if kingside and all(b[ksq + d] == 0 for d in (1, 2)) and \
                all(not attacked(b, ksq + d, -side) for d in (1, 2)):
            yield (ksq, ksq + 2, -1)
        if queenside and all(b[ksq - d] == 0 for d in (1, 2, 3)) and \
                all(not attacked(b, ksq - d, -side) for d in (1, 2)):
            yield (ksq, ksq - 2, -1)

def make(st, m):
    b, side, cast, ep, hm, key, wk, bk = st
    f, t, pr = m
    p = b[f]
    nb = b[:]
    if abs(p) == 1 and t == ep and (f & 7) != (t & 7):
        nb[t - 8 * side] = 0
    if abs(p) == 6 and abs(t - f) == 2:
        rf = t + 1 if t > f else t - 2
        rt = f + 1 if t > f else f - 1
        nb[rt] = nb[rf]
        nb[rf] = 0
    nb[t] = (side * PROMO[pr]) if pr >= 0 else p
    nb[f] = 0
    if abs(p) == 6:
        cast &= ~(3 if side == 1 else 12)
        if side == 1:
            wk = t
        else:
            bk = t
    if f == 7 or t == 7:
        cast &= ~1
    if f == 0 or t == 0:
        cast &= ~2
    if f == 63 or t == 63:
        cast &= ~4
    if f == 56 or t == 56:
        cast &= ~8
    nep = f + 8 * side if abs(p) == 1 and abs(t - f) == 16 else -1
    hm = 0 if abs(p) == 1 or b[t] else hm + 1
    return (nb, -side, cast, nep, hm, (tuple(nb), -side, cast, nep), wk, bk)

def lmoves(st, caps=False):
    """Legal moves paired with the state each produces."""
    side = st[1]
    for m in gen(st, caps):
        ns = make(st, m)
        k = ns[6] if side == 1 else ns[7]
        if not attacked(ns[0], k, -side):
            yield m, ns

def evaluate(st):
    b, side = st[0], st[1]
    score = 0
    bishops = [0, 0]
    for sq, p in enumerate(b):
        if p:
            s = 1 if p > 0 else -1
            k = abs(p)
            score += s * (V[k] + PST[k][sq if s == 1 else sq ^ 56])
            if k == 3:
                bishops[s == 1] += 1
    if bishops[0] > 1:
        score += 30
    if bishops[1] > 1:
        score -= 30
    return score if side == 1 else -score

class Abort(Exception):
    pass

NODES = 0
TT = {}
KILL = [[None, None] for _ in range(80)]
REP = []

def order(moves, st, ttm, ply):
    b = st[0]
    k = KILL[ply] if ply < 80 else [None, None]
    def rank(x):
        m = x[0]
        if m == ttm:
            return 100000
        v = b[m[1]]
        if v or m[2] >= 0:
            return 50000 + (V[abs(v)] if v else 0) * 16 - V[abs(b[m[0]])] + (900 if m[2] >= 0 else 0)
        if m == k[0]:
            return 40000
        if m == k[1]:
            return 39000
        return 0
    moves.sort(key=rank, reverse=True)
    return moves

def qsearch(st, alpha, beta, ply):
    global NODES
    NODES += 1
    if NODES >= LIMIT:
        raise Abort
    side = st[1]
    ksq = st[6] if side == 1 else st[7]
    chk = attacked(st[0], ksq, -side)
    if chk:
        moves = list(lmoves(st))
        if not moves:
            return -MATE + ply
        stand = -INF
    else:
        stand = evaluate(st)
        if stand >= beta:
            return stand
        if stand > alpha:
            alpha = stand
        moves = list(lmoves(st, True))
        if not moves:
            return stand
    for m, ns in order(moves, st, None, ply):
        if not chk and stand + V[abs(st[0][m[1]])] + 200 + (900 if m[2] >= 0 else 0) < alpha:
            continue
        v = -qsearch(ns, -beta, -alpha, ply + 1)
        if v >= beta:
            return v
        if v > alpha:
            alpha = v
    return alpha

def search(st, depth, alpha, beta, ply):
    global NODES
    NODES += 1
    if NODES >= LIMIT:
        raise Abort
    if st[4] >= 100 or st[5] in REP[:-1]:
        return 0
    key = st[5]
    entry = TT.get(key)
    ttm = entry[3] if entry else None
    if entry and entry[0] >= depth and ply:
        d, val, flag, _ = entry
        if flag == 0:
            return val
        if flag == 1 and val >= beta:
            return val
        if flag == 2 and val <= alpha:
            return val
    side = st[1]
    ksq = st[6] if side == 1 else st[7]
    chk = attacked(st[0], ksq, -side)
    if depth <= 0:
        return qsearch(st, alpha, beta, ply)
    moves = list(lmoves(st))
    if not moves:
        return -MATE + ply if chk else 0
    alpha0 = alpha
    best = -INF
    bestm = None
    REP.append(key)
    for m, ns in order(moves, st, ttm, ply):
        v = -search(ns, depth - 1, -beta, -alpha, ply + 1)
        if v > best:
            best, bestm = v, m
        if v > alpha:
            alpha = v
        if alpha >= beta:
            if st[0][m[1]] == 0 and m[2] < 0 and ply < 80:
                k = KILL[ply]
                if k[0] != m:
                    k[1] = k[0]
                    k[0] = m
            break
    REP.pop()
    flag = 0 if alpha0 < best < beta else (1 if best >= beta else 2)
    TT[key] = (depth, best, flag, bestm)
    return best

def parse_fen(fen):
    parts = fen.split()
    b = [0] * 64
    for r, row in enumerate(parts[0].split('/')):
        f = 0
        for ch in row:
            if ch.isdigit():
                f += int(ch)
            else:
                up = ch.isupper()
                ch = ch.lower()
                idx = 'pnbrqk'.index(ch)
                b[(7 - r) * 8 + f] = (idx + 1) * (1 if up else -1)
                f += 1
    side = 1 if parts[1] == 'w' else -1
    cast = 0
    for ch in parts[2]:
        cast |= {'K': 1, 'Q': 2, 'k': 4, 'q': 8}.get(ch, 0)
    ep = -1
    if parts[3] != '-':
        ep = (int(parts[3][1]) - 1) * 8 + 'abcdefgh'.index(parts[3][0])
    hm = int(parts[4]) if len(parts) > 4 else 0
    return (b, side, cast, ep, hm, (tuple(b), side, cast, ep), b.index(6 * side), b.index(-6 * side))

def sqname(sq):
    return 'abcdefgh'[sq & 7] + str((sq >> 3) + 1)

def uci(m):
    return sqname(m[0]) + sqname(m[1]) + ('qrbn'[m[2]] if m[2] >= 0 else '')

def from_uci(s):
    return ('abcdefgh'.index(s[0]) + (int(s[1]) - 1) * 8,
            'abcdefgh'.index(s[2]) + (int(s[3]) - 1) * 8,
            'qrbn'.index(s[4]) if len(s) == 5 else -1)

def choose(fen, legal):
    global NODES
    st = parse_fen(fen)
    roots = [(m, make(st, m)) for m in map(from_uci, legal)]
    if not roots:
        return legal[0]
    TT.clear()
    REP.clear()
    for k in KILL:
        k[0] = k[1] = None
    NODES = 0
    best = roots[0]
    for depth in range(1, MAXD + 1):
        alpha = -INF
        localbest = None
        localval = -INF
        try:
            for m, ns in order(roots[:], st, None, 0):
                v = -search(ns, depth - 1, -INF, -alpha, 1)
                if v > localval:
                    localval, localbest = v, m
                if v > alpha:
                    alpha = v
        except Abort:
            break
        if localbest is not None:
            best = localbest
        if localval > MATE - 100:
            break
    return uci(best)

if __name__ == '__main__':
    ENV_URL = os.environ.get('MAKEFUN_ENV_URL') or sys.exit('MAKEFUN_ENV_URL is not set')

    def post(path, body):
        req = urllib.request.Request(ENV_URL + path, data=json.dumps(body).encode(),
                                     headers={'content-type': 'application/json'})
        try:
            with urllib.request.urlopen(req) as res:
                return json.load(res)
        except urllib.error.HTTPError as e:
            sys.exit(f'{path}: HTTP {e.code} {e.read().decode(errors="replace")}')

    while True:
        g = post('/game', {})
        if g['status'] == 'done':
            break
        while g['status'] == 'your_move':
            g = post('/move', {'game': g['game'],
                               'move': choose(g['fen'], g['legal_moves'])})
        print(f"game {g['game']}: {g['outcome']} by {g['reason']}", file=sys.stderr)
    print(f"done: {g.get('wins')} won, {g.get('draws')} drawn, {g.get('losses')} lost", file=sys.stderr)
